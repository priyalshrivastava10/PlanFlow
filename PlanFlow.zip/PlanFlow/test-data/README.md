# test-data/

- PlanFlow_test_inputs.txt : the 10 test inputs (4 normal, 4 edge, 2 invalid) with the system prompt
- results_v1.xlsx, results_v2.xlsx, results_v3.xlsx : observations from the 5 runs of each prompt version
- Add the raw output of every run here (v1_run1_output.csv ... and test01_output.txt ... test10_output.txt)
